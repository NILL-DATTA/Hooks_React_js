import React from 'react'

const Update_Password = () => {
  return (
    <div>
      
    </div>
  )
}

export default Update_Password
